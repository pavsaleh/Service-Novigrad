https://github.com/SEG2105-uottawa/project_GR-55

# SEG2105 PROJECT
## Team member

* Pavly Saleh 
  * 300012936
  * psale041@uottawa.ca

* Default admin account
  * username: admin
  * password: admin