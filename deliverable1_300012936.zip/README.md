https://github.com/SEG2105-uottawa/seg2105f20-project-project_gr-55

# SEG2105 PROJECT
## Team member

* Pavly Saleh 
  * 300012936
  * psale041@uottawa.ca

* Default admin account
  * username: admin
  * password: admin